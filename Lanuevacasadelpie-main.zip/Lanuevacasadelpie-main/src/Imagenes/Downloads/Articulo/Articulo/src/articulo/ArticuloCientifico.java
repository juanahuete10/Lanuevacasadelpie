/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package articulo;

/**
 *
 * @author Hp
 */
public class ArticuloCientifico extends Articulo {

    public ArticuloCientifico(String la_teoria_de_la_relatividad, String _Albert_Einstein, String[] palabras, String anales_de_fisica, int i, String leyes_de_la_fisica_son_las_mismas_en_todo) {
    }
    
}
